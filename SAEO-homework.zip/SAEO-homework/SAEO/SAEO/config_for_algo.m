function cfg = config_for_algo(varargin)
    if nargin == 0
        cfg.fileName = "LSAG";  % 使用调度算法
        
        % 基本参数：作业数、机器数、操作数
        cfg.n = 15;  % 作业数 n
        cfg.m = 100;   % 机器数 m
        cfg.q = 3;   % 每个作业的操作数 q

        % 计算任务类型数
        cfg.a = 3;   % 计算任务类型数 a
        
        % 作业处理时间
        cfg.processing_time = generateUniform(cfg.n * cfg.q * cfg.m, 40, 180);  
        cfg.processing_time = reshape(cfg.processing_time, cfg.n * cfg.q, cfg.m);
        
        % 作业截止时间
        cfg.deadline = generateUniform(cfg.n, 400, 3000);
        
        % 计算任务的属性
        cfg.task_attributes.C = generateUniform(cfg.n * cfg.q * cfg.a, 100, 1000);  
        cfg.task_attributes.C = reshape(cfg.task_attributes.C, [cfg.n, cfg.q, cfg.a]);
        cfg.task_attributes.D = generateUniform(cfg.n * cfg.q * cfg.a, 100, 1000);  
        cfg.task_attributes.D = reshape(cfg.task_attributes.D, [cfg.n, cfg.q, cfg.a]);

        % 任务的重要性
        cfg.task_importance = generateUniform(cfg.n, 0, 1);  % 随机生成任务的重要性
        
        % 机器的计算能力
        cfg.machines.f = generateUniform(cfg.m, 1e1, 1e2);  
        
        % 边缘计算节点（ECN）的计算能力
        cfg.ECN.f = 2e4;  
        
        % 云中心的计算能力
        cfg.Cloud.f = 2e6;  
        
        % 通信参数
        cfg.communication = struct();
        cfg.communication.B = 1e2;  
        cfg.communication.H = 2e-5;  
        cfg.communication.P = 0.1;  
        cfg.communication.sigma2 = 1e-9;  
        % 数据传输速率
        cfg.communication.edgeSpeed = 1e3;  % 边缘传输速率
        cfg.communication.cloudSpeed = 1e2;  % 云端传输速率
        
        % 机器负载
        cfg.machine_load = generateUniform(cfg.m, 0, 1);  % 随机生成机器负载
        
        % 任务执行时间
        cfg.task_execution_time = generateUniform(cfg.n, 10, 100);  % 随机生成任务执行时间
        
        % 计算每个任务的总CPU需求
        cfg.task_cpu_demand = sum(cfg.task_attributes.C, 2);  % 对每个任务的所有操作求和
    end
    
    cfg.execMode = "train";
    cfg.numOfParticles = 10;   
    cfg.totalIterations = 500; 
    cfg.amplify = 2;            
end