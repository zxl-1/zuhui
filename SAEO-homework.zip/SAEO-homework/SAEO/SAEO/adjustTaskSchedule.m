function [schedule, task_allocation, offloading_decision, processing_time, task_attributes] = adjustTaskSchedule(cfg, schedule, task_allocation, offloading_decision)
    n = cfg.n; % 作业数
    q = cfg.q; % 每个作业的操作数
    m = cfg.m; % 机器数
    a = cfg.a; % 计算任务类型数

    % 计算每个任务的总等待时间和重要性惩罚
    [task_completion_time, task_wait_time] = ...
        get_schedule(cfg, schedule, task_allocation, offloading_decision, cfg.processing_time, cfg.task_attributes);

    % 计算每个任务的总等待时间乘以任务权重
    task_total_wait_time = task_wait_time .* cfg.task_importance;

    % 引入任务紧迫性指数
    task_urgency_index = exp((-cfg.deadline - task_wait_time) .* cfg.task_importance);

    % 引入机器负载均衡因子
    % machine_load_balance_factor = 1 ./ (1 + sum(cfg.machine_load));

    % 引入资源需求指数，资源需求量小的任务优先执行
    % 假设 cfg.resource_demand 存储了每个任务的资源需求量
    resource_demand_index =1 ./ cfg.task_cpu_demand;

    % 计算非线性的优先级分数
    % 由于资源需求量大的任务优先执行，我们直接使用 resource_demand_index 而不是其倒数
    task_priority_score = task_total_wait_time .* task_urgency_index .* resource_demand_index;

    % 根据优先级分数对任务进行排序
    [~, sorted_indices] = sort(task_priority_score, 'descend');

    % 更新调度决策以反映新的任务顺序
    schedule = schedule(sorted_indices, :);
    task_allocation = task_allocation(sorted_indices, :);
    offloading_decision = offloading_decision(sorted_indices, :);

    % 更新任务属性以反映新的任务顺序
    task_attributes.C = cfg.task_attributes.C(sorted_indices, :, :);
    task_attributes.D = cfg.task_attributes.D(sorted_indices, :, :);

    % 更新处理时间以反映新的任务顺序
    new_processing_time = zeros(size(cfg.processing_time));
    for i = 1:n
        for j = 1:q
            operation_index = (i - 1) * q + j;
            new_processing_time(sorted_indices(operation_index), :, :) = cfg.processing_time(operation_index, :, :);
        end
    end
    processing_time = new_processing_time;
end