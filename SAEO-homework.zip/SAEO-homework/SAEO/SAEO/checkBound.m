function [schedule_new, task_allocation_new, offloading_decision_new] = ...
    checkBound(n, m, schedule, task_allocation, offloading_decision)
    %% 2.1 check lower bound:
    % 确保每个作业都被分配到至少一个机器
    schedule_new = schedule;
    for i = 1:n
        for j = 1:size(schedule, 2)
            if schedule(i, j) == 0
                schedule_new(i, j) = randi(m); % 随机分配一个机器
            end
        end
    end

    % 确保每个任务都被分配到至少一个计算资源
    task_allocation_new = task_allocation;
    for i = 1:n
        for j = 1:size(task_allocation, 2)
            if task_allocation(i, j) == 0
                task_allocation_new(i, j) = randi([1, 3]); % 随机分配一个计算资源
            end
        end
    end

    % 确保卸载决策变量的合法性
    offloading_decision_new = offloading_decision;
    for i = 1:n
        for j = 1:size(offloading_decision, 2)
            if offloading_decision(i, j) == 0
                offloading_decision_new(i, j) = randi([1, 3]); % 随机分配一个卸载决策
            end
        end
    end
end