function [val, fe, pop, popSample, valSample] = evaluate_l(fname, func_num, pop, pop_temp, val, fe, NP, popSample, valSample)
    % 计算新种群的适应值
    val_temp = feval(fname, pop_temp, func_num); % 评估 pop_temp 的适应值
    fe = fe + NP; % 更新评估次数

    % 确保 popSample 和 valSample 的维度一致
    if isempty(popSample)
        popSample = pop_temp; % 初始化 popSample
    else
        popSample = [popSample; pop_temp]; % 合并样本种群
    end

    if isempty(valSample)
        valSample = val_temp; % 初始化 valSample
    else
        valSample = [valSample(:); val_temp(:)]; % 确保为列向量后拼接
    end

    % 更新主种群和适应值
    index = find(val_temp < val); % 找到适应值改进的位置

    % 防止索引超出边界
    valid_idx = index(index <= size(pop_temp, 1) & index <= size(pop, 1));

    % 更新种群和适应值
    if ~isempty(valid_idx)
        pop(valid_idx, :) = pop_temp(valid_idx, :);
        val(valid_idx) = val_temp(valid_idx);
    end
end
