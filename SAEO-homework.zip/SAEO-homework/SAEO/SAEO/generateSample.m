
function [pop, tracerst,popSample,valSample,bestval,val,fid,iter,fe,ibest,best] = generateSample(fname,func_num, Lbound, Ubound,D,NP,FE1,runindex,fid,Max_FEs,best)
% for fitness trace
tracerst = [];
popSample = [];
valSample = [];
% the initial population
pop = Lbound + lhsdesign(NP, D).* (Ubound-Lbound);
popSample = pop;
val = feval(fname, pop, func_num);
valSample = val;
[bestval,ibest] = min(val);
tracerst = [tracerst; bestval];
bestmem = pop(ibest,:);
fe = 0;
fe = fe + NP;
fprintf(1, 'runindex = %d, fun = %d, Gen = %d, bestval = %e\n',  runindex, func_num, 1, bestval);
iter = 1;
best(iter) = bestval;

while (fe <  FE1)
    
    %generate offspring
    [pop,val,fe,iter,tracerst,popSample,valSample,best] = tlbo(fname, func_num, runindex, D, NP,pop, val, Lbound, Ubound, bestmem,fe,Max_FEs,iter,tracerst,popSample,valSample,best);
    [bestval, ibest] = min(val);
    bestmem = pop(ibest,:);
    
end
end