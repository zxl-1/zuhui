
%% Uniform distribution
% function : Generate uniform distribution between 
%            lower and upper, key is the number of elements in x
% Example  : x = generateUniform(3,-2,2) -> x = [-2,0,2]
function x = generateUniform(key,lower,upper)
    % 如果只返回一个数，就取上界和下届之间的中值
    % 如果不是只返回一个数，就是返回上界和下界之间的随机数，他们是均匀分布的
    if key == 1
        x = lower + (upper-lower)/2;
    else
        % 计算步长，然后根据步长从最低到最高，返回一个序列，数字之间的间隔为步长
        d = (upper-lower)/(key-1);
        x = lower:d:upper;
    end
end
