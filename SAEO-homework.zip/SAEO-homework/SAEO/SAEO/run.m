clear;


% set random seed
rand('state', sum(100*clock));
randn('state', sum(100*clock));
D = 100; % dimensionality of benchmark functions
NP = 50; % population size
runs = 1; % number of independent runs for each function, should be set to 25
Max_FEs = 50000; % maximal number of FEs, should be set to 3e+06


global initial_flag; % the global flag used in test suite

for fun = [15]
    best = [];
    func_num = fun;
    time = [];
    for runindex = 1:runs
        tstart=tic;
        % trace the fitness
        fprintf(1, 'Function %02d, Run %02d\n', func_num, runindex);
        filename = sprintf('trace/SAEO_D200_trace_f%02d_%02d.txt', func_num, runindex);
        fid = fopen(filename, 'w');
        
        % set the lbound and ubound
        [Lbound, Ubound] = funRange(func_num, D, NP);
        
        initial_flag = 0;
        
        FE1 = 150;  % phase one
        
        [pop, tracerst,popSample,valSample,bestval,val,fid,iter,fe,ibest,best] = generateSample('benchmark_func',func_num, Lbound, Ubound,D,NP,FE1,runindex,fid,Max_FEs,best);
        
        %population size
        N1 = min(NP,ceil(NP*((Max_FEs-fe)/Max_FEs)^(300/D)));
        N2 = NP-N1;
        %assign population
        [val,index] = sort(val);
        pop = pop(index,:);
        val = val(index,:);
        pop2 = pop(1:N2,:);
        pop1 = pop(N2+1:end,:);
        val2 = val(1:N2,:);
        val1 = val(N2+1:end,:);
        bestmem = pop(1,:);
        
        %autoencoder training 
        autoenco = trainAutoencoder (popSample', 10,'MaxEpochs',10);
        
        
        %phase two
        while (fe<Max_FEs)
            
            %autoencoder-assisted optimization
            % encoder
            pop_dt = encode(autoenco, pop1');
            pop_d = pop_dt';
            [d] = size (pop_d,2);
            [Lb, Ub] = funRange(func_num, D, N1);
            [Lb2, Ub2] = funRange(func_num, D, N2);

            %generate offspring by learning
            [pop_temp] = generate_l(d, N1, pop_d, val1, fe, Max_FEs); 
            
            %decoder
            pop_DT = decode(autoenco, pop_temp');
            pop_temp = pop_DT';
            
            %evaluation
            [val1, fe, pop1,popSample,valSample]=evaluate_l('benchmark_func',func_num, pop1, pop_temp,val1,fe,N1,popSample,valSample);
            
            
            %surrogate-assisted optimization
            if fe<20*D
                %generate offspring by teaching
                [pop2, val2, fe,popSample,valSample] = generate_t('benchmark_func',func_num, D, N2, pop2, Lb2, Ub2, bestmem,val2,fe,popSample,valSample);
            elseif fe >=20*D  && fe < 20*D
                srgtOPT=srgtsRBFSetOptions(popSample, valSample, @my_rbfbuild, [], 'CUB',0.0002,1);
                srgtSRGT = srgtsRBFFit(srgtOPT);
                [pop2, val2, fe,popSample,valSample] = generate_s('benchmark_func',func_num, D, N2, pop2, bestmem,val2,fe, srgtSRGT,popSample,valSample,bestval);
            else
                [pop2, val2, fe,popSample,valSample] = generate_t('benchmark_func',func_num, D, N2, pop2, Lb2, Ub2, bestmem,val2,fe,popSample,valSample);
            end

            %assign population
            N1 = min(NP,ceil(NP*((Max_FEs-fe)/Max_FEs)^(300/D)));
            N2 = NP-N1;
            pop = [pop1;pop2];
            val = [val1;val2];
            [val1,index] = sort(val);
            pop = pop(index,:);
            val = val(index,:);
            pop2 = pop(1:N2,:);
            pop1 = pop(N2+1:end,:);
            val2 = val(1:N2,:);
            val1 = val(N2+1:end,:);
            bestvalue = min(val);
            
            if bestvalue<bestval
                bestval = bestvalue;
                bestmem = pop(1,:);
            end
            best(iter) = bestval;
            iter = iter +1;
            tracerst = [tracerst; bestval];
            fprintf(1, 'runindex = %d, fun = %d, Gen = %d, bestval = %e\n',  runindex, func_num, iter, bestval);
            save("SAEO-result","best","bestmem","bestval");

        end

    end
end


