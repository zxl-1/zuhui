function [pop,val,fe,popSample,valSample] = generate_s(fname, func_num, D, NP, pop, bestmem,val,fe,srgtSRGT,popSample,valSample,bestval)


Tg = bestmem;

%%%%%%%%%%%%%%%%%%%%%%%%
rand1 = (rand(NP,D) > 0.5) + ones(NP,D);
diffMean = rand(NP,D).*(repmat(Tg,NP,1)-rand1.*pop);
pop_temp1 = pop + diffMean;




pop_temp = [pop_temp1];
pre= my_rbfpredict(srgtSRGT.RBF_Model, srgtSRGT.P, pop_temp);
[pre_best, ind] = sort(pre);
n=0;
re = 5;
for i=1:NP
    if pre(i)<val(i)
        n=n+1;
    end
end

if n<re
    for i=1:NP
        if pre(i)<val(i)
            val(i) = feval(fname, pop_temp(i,:), func_num);
            fe = fe + 1;
            popSample = [popSample; pop_temp(i,:)];
            valSample = [valSample;val(i)];
        end
    end
else
    val(ind(1:re)) = feval(fname, pop_temp(ind(1:re),:), func_num);
    fe = fe + re;
end

pop = pop_temp;

end