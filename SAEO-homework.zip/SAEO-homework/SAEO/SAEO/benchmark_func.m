function f = benchmark_func(x,func_num)
global initial_flag
persistent fhd f_bias
initial_flag = 0; % 初始设置为未初始化

if initial_flag==0
    if func_num==1  fhd = str2func('fsphere');
    elseif func_num==2 fhd=str2func('rosenbrock_func');
    elseif func_num==3 fhd=str2func('rastrigin_func');  
    elseif func_num==4 fhd=str2func('ackley_func');
    elseif func_num==5 fhd=str2func('griewank_func');
    elseif func_num==6 fhd=str2func('rastrigin_rot_func');  
    elseif func_num==7 fhd=str2func('hybrid_rot_func');
    elseif func_num==8 fhd=str2func('hybrid_rot_func_narrow');
    elseif func_num == 12 fhd = str2func('F2');
    elseif func_num == 13 fhd = str2func('F3');
    elseif func_num == 14 fhd = str2func('F12');
    elseif func_num == 15 fhd = @Factory;
    end
    
%     load('./datafiles/fbias_data');
end

f=feval(fhd,x);

%12. F2 Function
%function fit = F2(x)
    %fit = sum(abs(x)) + prod(abs(x));  % f(x) = sum(|x|) + prod(|x|)
function fit = F2(x)
    absx = abs(x);
    fit = sum(absx, 2) + prod(absx, 2);
end
%13. F3 Function
function fit = F3(x)
    [rows, dim] = size(x);
    fit = zeros(rows, 1); 
    for i = 1:rows
        for j = 1:dim
            tempsum = sum(x(i, 1:j)); 
            fit(i) = fit(i) + tempsum^2; 
        end
    end
end

%14. F12 Function
function fit = F12(x)
    [rows, dim] = size(x);  
    fit = zeros(rows, 1);   
    pi_val = pi;  

    for i = 1:rows
        term1 = 10 * (sin(pi_val * (1 + (x(i, 1) + 1)/4))^2);
        term2 = sum(((x(i, 1:dim-1) + 1) / 4).^2 .* ...
                    (1 + 10 * (sin(pi_val * (1 + (x(i, 2:dim) + 1)/4)).^2)));
        term3 = ((x(i, dim) + 1)/4)^2;
        U_term = sum(Ufun(x(i, :), 10, 100, 4));  
        fit(i) = (pi_val/dim) * (term1 + term2) + term3 + U_term;  
    end
end

function u = Ufun(x, a, k, m)
    dim = length(x);  
    u = zeros(1, dim);  
    for i = 1:dim
        if x(i) > a
            u(i) = k * ((x(i) - a) ^ m);
        elseif x(i) < -a
            u(i) = k * ((-x(i) - a) ^ m);
        else
            u(i) = 0;  
        end
    end

end



% Factory
function fit = Factory(x)
    % 初始化参数
    cfg = config_for_algo(); % 假设这个函数返回一个配置结构体
    n = cfg.n; % 作业数
    m = cfg.m; % 机器数
    q = cfg.q; % 每个作业的操作数
    a = cfg.a; % 计算任务类型数
    numOfDimensions = n * q + n * q * a; % 总维度
    [rows, dim] = size(x); 
    fit = zeros(rows,1);


    for i=1:rows

        % 转换粒子位置为决策变量
        [numOfOperations, numOfTasks] = deal(n * q, n * q * a); % 使用deal函数同时赋值
        %disp(x)
        [schedule, task_allocation, offloading_decision] = vector2matrix(n, m, x(i), numOfOperations, numOfTasks);
    
        % 检查边界条件
        [schedule, task_allocation, offloading_decision] = checkBound(n, m, schedule, task_allocation, offloading_decision);
        
        % 根据任务的重要性和预计运行时间调整任务调度顺序
        [schedule, task_allocation, offloading_decision, processing_time, task_attributes] = adjustTaskSchedule(cfg, schedule, task_allocation, offloading_decision);
        
        % 计算目标函数
        [makespan, total_offloading_delay, penalty, importance_penalty,total_pen] = objFunction(cfg, schedule, task_allocation, offloading_decision, processing_time, task_attributes);
        obj = makespan + total_offloading_delay + penalty + importance_penalty;
        
%         fit(i) = sum(total_pen,"all")/(n*q);
        fit(i) = obj(1);
    end
end

function [schedule, task_allocation, offloading_decision] = vector2matrix(n, m, Position, numOfOperations, numOfTasks)
    % 初始化决策变量矩阵
    schedule = zeros(n, numOfOperations); % 作业调度方案
    task_allocation = zeros(n, numOfTasks); % 任务分配矩阵
    offloading_decision = zeros(n, numOfTasks); % 卸载决策变量

    % 将Position中的数据转换为决策变量矩阵
    operation_index = 1;
    task_index = numOfOperations + 1;  % 将任务索引初始化为操作数结束后的下一个索引

    for i = 1:n
        for j = 1:numOfOperations
            % 确保 operation_index 不超出 Position 的范围
            if operation_index <= length(Position)
                machine_index = round(Position(operation_index));
                schedule(i, j) = min(max(machine_index, 1), m); % 确保 machine_index 在 [1, m] 范围内
                operation_index = operation_index + 1;
            end
        end
        for j = 1:numOfTasks
            % 确保 task_index 不超出 Position 的范围
            if task_index <= length(Position)
                task_type = round(Position(task_index));
                
                if task_type <= 0
                    task_type = 1;
                elseif task_type > 3
                    task_type = 3;
                end
                offloading_decision(i, j) = task_type;
                task_index = task_index + 1;
            end
        end
    end
end



% 1. Ellipsoid Function
function fit = ellipsoid_func(x)    
    d = size(x, 2);
    fi = 1:d;
    fit = sum(fi .* x.^2, 2);
end

% 2. Rosenbrock Function
function fit = rosenbrock_func(x)
    D = size(x, 2);
    fit = sum(100 .* (x(:, 1:D-1).^2 - x(:, 2:D)).^2 + (x(:, 1:D-1) - 1).^2, 2);
end

% 3. Rastrigin Function
function fit = rastrigin_func(x)
    [ps, D] = size(x);
    fit = sum(x.^2 - 10 .* cos(2 .* pi .* x) + 10, 2);
end

% 4. Ackley Function
function fit = ackley_func(x)
    D = size(x, 2);
    fit = sum(x.^2, 2);
    fit = 20 - 20 .* exp(-0.2 .* sqrt(fit ./ D)) - exp(sum(cos(2 .* pi .* x), 2) ./ D) + exp(1);
end

% 5. Griewank Function
function fit = griewank_func(x)
    D = size(x, 2);
    sumcomp = sum(x.^2, 2);
    prodcomp = prod(cos(x ./ sqrt(1:D)), 2);
    fit = (sumcomp / 4000) - prodcomp + 1;
end

% 6. Shifted Rotated Rastrigin Function
function f = rastrigin_rot_func(x)
    persistent o M
    [ps, D] = size(x);
    if initial_flag == 0
        load('./datafiles/rastrigin_func_data');
        if length(o) >= D
            o = o(1:D);
        else
            o = -5 + 10 * rand(1, D);
        end
        c = 2;
        if D == 2
            load('./datafiles/rastrigin_M_D2');
        elseif D == 10
            load('./datafiles/rastrigin_M_D10');
        elseif D == 30
            load('./datafiles/rastrigin_M_D30');
        elseif D == 50
            load('./datafiles/rastrigin_M_D50');
        else
            M = rot_matrix(D, c);
        end
        initial_flag = 1;
    end
    x = (x - repmat(o, ps, 1)) * M;
    f = sum(x.^2 - 10 .* cos(2 .* pi .* x) + 10, 2) - 330;
end

% 7. Rotated Hybrid Composition Function
function fit = hybrid_rot_func(x)
    fit = hybrid_rot_func_general(x, 10, [1, 2, 1.5, 1.5, 1, 1, 1.5, 1.5, 2, 2], ...
        [2*5/32, 5/32, 2*1, 1, 2*5/100, 5/100, 2*10, 10, 2*5/60, 5/60]);
end

% 8. Rotated Hybrid Composition Function with Narrow Basin
function fit = hybrid_rot_func_narrow(x)
    fit = hybrid_rot_func_general(x, 10, [0.1, 2, 1.5, 1.5, 1, 1, 1.5, 1.5, 2, 2], ...
        [0.1*5/32, 5/32, 2*1, 1, 2*5/100, 5/100, 2*10, 10, 2*5/60, 5/60]);
end

% Generalized Hybrid Rotated Composition Function
function fit = hybrid_rot_func_general(x, fun_num, sigma, lamda)
    persistent func o bias M
    if initial_flag == 0
        D = size(x, 2);
        initial_flag = 1;
        load('./datafiles/hybrid_func2_data');
        if length(o(1, :)) >= D
            o = o(:, 1:D);
        else
            o = -5 + 10 * rand(fun_num, D);
        end
        o(end, :) = 0;
        func = {str2func('fackley'), str2func('fackley'), ...
            str2func('frastrigin'), str2func('frastrigin'), ...
            str2func('fsphere'), str2func('fsphere'), ...
            str2func('fweierstrass'), str2func('fweierstrass'), ...
            str2func('fgriewank'), str2func('fgriewank')};
        bias = ((1:fun_num) - 1) * 100;
        lamda = repmat(lamda, 1, D);
        c = [2, 3, 2, 3, 2, 3, 20, 30, 200, 300];
        for i = 1:fun_num
            eval(['M.M' int2str(i) ' = rot_matrix(D, c(i));']);
        end
    end
    fit = hybrid_composition_func(x, fun_num, func, o, sigma, lamda, bias, M) + 10;
end
end