function [makespan, total_offloading_delay, penalty, importance_penalty, task_completion_time, task_wait_time,total_pen] = objFunction(cfg, schedule, task_allocation, offloading_decision, processing_time, task_attributes)
    n = cfg.n; % 作业数
    m = cfg.m; % 机器数
    q = cfg.q; % 每个作业的操作数
    a = cfg.a; % 计算任务类型数
    f_machine = cfg.machines.f; % 机器的计算能力

    makespan = 0;
    total_offloading_delay = 0;
    penalty = 0;
    importance_penalty = 0; % 基于任务重要性和等待时间的惩罚项
    task_completion_time = zeros(n, q); % 每个任务的完成时间
    task_wait_time = zeros(n, 1); % 每个任务的总等待时间

    % 初始化每个机器的忙碌时间
    machine_busy_time = zeros(m, 1);
    total_pen = 0;

    % 计算每个操作的完成时间
    for i = 1:n
        for j = 1:q
            operation_index = (i - 1) * q + j;
            machine_index = min(max(round(schedule(operation_index)), 1), m); % 确保 machine_index 在 [1, m] 范围内
            
            % 获取任务类型和相关属性
            task_type = offloading_decision(i, j);
            task_CPU = task_attributes.C(i, j, task_type);
            task_Data = task_attributes.D(i, j, task_type);
            
            % 计算传输延迟和计算时间
            if task_type == 1 % 本地计算
                upload_delay = 0;
                local_delay = task_CPU / f_machine(machine_index);
            elseif task_type == 2 % 边缘计算
                upload_delay = task_Data / cfg.communication.edgeSpeed;
                local_delay = task_CPU / cfg.ECN.f;
            else % 云计算
                upload_delay = task_Data / cfg.communication.cloudSpeed;
                local_delay = task_CPU / cfg.Cloud.f;
            end
            
            % 计算操作的总完成时间
            % disp(processing_time)
            operation_completion_time = upload_delay + local_delay + processing_time(operation_index, machine_index);
            
            % 更新机器的忙碌时间
            machine_busy_time(machine_index) = machine_busy_time(machine_index) + operation_completion_time;
            
            % 更新任务的总完成时间
            if j == 1
                task_completion_time(i, j) = machine_busy_time(machine_index);
            else
                task_completion_time(i, j) = task_completion_time(i, j-1) + operation_completion_time;
            end
            
            % 累加总卸载延迟
            total_offloading_delay = total_offloading_delay + upload_delay;
            
            % 计算任务的总等待时间
            if j == 1
                task_wait_time(i) = 0; % 第一个操作的等待时间为0
            else
                task_wait_time(i) = task_wait_time(i) + max(0, machine_busy_time(machine_index) - task_completion_time(i, j-1));
            end
        end
        % 计算整个任务的基于重要性的等待时间惩罚项
        importance_penalty = importance_penalty + cfg.task_importance(i) * task_wait_time(i);
        penalty =penalty+sum(max(task_completion_time - cfg.deadline(i), 0).^2);
    end

    % 计算作业完成时间（makespan）为所有任务完成时间的最大值
    makespan = max(task_completion_time(:));

    % 计算惩罚项
    %penalty = sum(max(task_completion_time - cfg.deadline, 0).^2);
    
    % 增强目标函数，结合作业完成时间和总卸载延迟
    augmentedObj = sum(makespan + total_offloading_delay + cfg.amplify * penalty + importance_penalty/(n*q));
    total_pen = sum(penalty+ importance_penalty,"all")/(n*q);
end