function [pop,val,fe,iter,tracerst,popSample,valSample,best] = tlbo(fname, func_num, runindex, D, NP, pop, val, Lbound, Ubound, bestmem,fe,Max_FEs,iter,tracerst,popSample,valSample,best)

if(fe<Max_FEs)
    Tg = bestmem;
    Mg = sum(pop)./NP;
    
    %%%%%%%%%%%%%%%%%%%%%%%%
    rand2 = (rand > 0.5) + 1;
    diffM = rand(1, D) .* (Tg -  rand2 * Mg);
    diffMean = repmat(diffM, NP, 1);
    
    pop_temp = pop + diffMean;
    pop_temp = repair(pop_temp, Lbound,Ubound);
    val_temp = feval(fname, pop_temp, func_num);
    fe = fe + NP;
    iter = iter+1;
    
    index = find(val_temp < val);
    pop(index,:) = pop_temp(index,:);
    val(index) = val_temp(index);
    popSample = [popSample;pop];
    valSample = [valSample;val];
    [bestval,ibest] = min(val);
    tracerst = [tracerst;bestval];
    best(iter) = bestval;
    fprintf(1, 'runindex = %d, fun = %d, Gen = %d, bestval = %e\n',  runindex, func_num, iter, bestval);
end
%$End Teacher phase



%Learner phase
if(fe<Max_FEs)
    for l = 1: NP
        
        randomRowNumber = floor(rand() * NP);
        if(randomRowNumber == 0)
            randomRowNumber = randomRowNumber + 1;
        end
        
        
        if( val(l) < val(randomRowNumber) )
            pop_temp2(l,:) = pop(l,:) + (rand > 0.5) * (pop(l,:) - pop(randomRowNumber,:));
        else
            pop_temp2(l,:) = pop(l,:) + (rand > 0.5) * (pop(randomRowNumber,:) - pop(l,:));
        end
    end
    
    pop_temp2 = repair(pop_temp2,Lbound, Ubound);
    val_temp2 = feval(fname, pop_temp2, func_num);
    fe = fe + NP;
    iter = iter+1;
    index = find(val_temp2 < val);
    pop(index,:) = pop_temp2(index,:);
    val(index) = val_temp2(index);
    popSample = [popSample;pop];
    valSample = [valSample;val];
    [bestval,ibest] = min(val);
    tracerst = [tracerst;bestval];
    best(iter) = bestval;
    fprintf(1, 'runindex = %d, fun = %d, Gen = %d, bestval = %e\n',  runindex, func_num, iter, bestval);
end
end
